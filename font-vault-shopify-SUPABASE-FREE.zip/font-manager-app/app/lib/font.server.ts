import { prisma } from "~/shopify.server";
import type { FontFile, TypographySettings } from "@prisma/client";

// ─── Font CRUD Operations ─────────────────────────────────────────────────────

export async function getFonts(shop: string): Promise<FontFile[]> {
  return prisma.fontFile.findMany({
    where: { shop },
    orderBy: [{ family: "asc" }, { weight: "asc" }],
  });
}

export async function getFontById(id: string, shop: string) {
  return prisma.fontFile.findFirst({ where: { id, shop } });
}

export async function createFont(data: {
  shop: string;
  name: string;
  family: string;
  weight: string;
  style: string;
  format: string;
  fileName: string;
  fileUrl: string;
  fileSize: number;
  category: string;
}) {
  return prisma.fontFile.create({ data });
}

export async function deleteFont(id: string, shop: string) {
  return prisma.fontFile.delete({ where: { id, shop } });
}

// ─── Typography Settings ──────────────────────────────────────────────────────

export async function getTypographySettings(shop: string): Promise<TypographySettings | null> {
  return prisma.typographySettings.findUnique({ where: { shop } });
}

export async function upsertTypographySettings(
  shop: string,
  data: Partial<Omit<TypographySettings, "id" | "shop" | "createdAt" | "updatedAt">>
) {
  return prisma.typographySettings.upsert({
    where: { shop },
    update: { ...data, updatedAt: new Date() },
    create: { shop, ...data },
  });
}

// ─── CSS Generation ───────────────────────────────────────────────────────────

export function generateFontFaceCSS(fonts: FontFile[]): string {
  // Group fonts by family
  const families = new Map<string, FontFile[]>();
  fonts.forEach((font) => {
    const key = font.family;
    if (!families.has(key)) families.set(key, []);
    families.get(key)!.push(font);
  });

  let css = `/* ╔═══════════════════════════════════════════╗
 *   Font Vault — Custom Font Declarations   
 *   Auto-generated. Do not edit manually.  
 * ╚═══════════════════════════════════════════╝ */\n\n`;

  families.forEach((familyFonts, family) => {
    familyFonts.forEach((font) => {
      const format = getFormatString(font.format);
      css += `@font-face {
  font-family: "${family}";
  src: url("${font.fileUrl}") format("${format}");
  font-weight: ${font.weight};
  font-style: ${font.style};
  font-display: swap;
}\n\n`;
    });
  });

  return css;
}

export function generateTypographyCSS(
  settings: Partial<TypographySettings>,
  fonts: FontFile[]
): string {
  const headingFont = settings.headingFontFamily
    ? `"${settings.headingFontFamily}", sans-serif`
    : null;
  const bodyFont = settings.bodyFontFamily
    ? `"${settings.bodyFontFamily}", sans-serif`
    : null;
  const buttonFont = settings.buttonFontFamily
    ? `"${settings.buttonFontFamily}", sans-serif`
    : null;
  const navFont = settings.navFontFamily
    ? `"${settings.navFontFamily}", sans-serif`
    : null;
  const metaFont = settings.metaFontFamily
    ? `"${settings.metaFontFamily}", sans-serif`
    : null;

  const fontFaceCSS = generateFontFaceCSS(fonts);

  let css = fontFaceCSS;
  css += `/* ─── Typography Override Variables ─── */\n`;
  css += `:root {\n`;
  if (headingFont) css += `  --font-vault-heading: ${headingFont};\n`;
  if (bodyFont) css += `  --font-vault-body: ${bodyFont};\n`;
  if (buttonFont) css += `  --font-vault-button: ${buttonFont};\n`;
  if (navFont) css += `  --font-vault-nav: ${navFont};\n`;
  if (metaFont) css += `  --font-vault-meta: ${metaFont};\n`;
  css += `}\n\n`;

  // Body text overrides
  if (bodyFont) {
    css += `/* ─── Body Typography ─── */\n`;
    css += `body,\nbody *:not(h1):not(h2):not(h3):not(h4):not(h5):not(h6):not(button):not(.btn):not([class*="btn"]):not(nav) {\n`;
    css += `  font-family: ${bodyFont};\n`;
    css += `  font-size: ${settings.bodyFontSize || "1rem"};\n`;
    css += `  font-weight: ${settings.bodyFontWeight || "400"};\n`;
    css += `  line-height: ${settings.bodyLineHeight || "1.6"};\n`;
    css += `  letter-spacing: ${settings.bodyLetterSpacing || "0em"};\n`;
    if (settings.bodyColor) css += `  color: ${settings.bodyColor};\n`;
    if (settings.bodyTextTransform && settings.bodyTextTransform !== "none")
      css += `  text-transform: ${settings.bodyTextTransform};\n`;
    css += `}\n\n`;

    css += `p, span, li, a, div, section, article {\n`;
    css += `  font-family: ${bodyFont} !important;\n`;
    css += `}\n\n`;
  }

  // Heading overrides
  if (headingFont) {
    css += `/* ─── Heading Typography ─── */\n`;
    const headingSizes = [
      { tag: "h1", size: settings.headingFontSize || "2.5rem" },
      { tag: "h2", size: settings.headingH2Size || "2rem" },
      { tag: "h3", size: settings.headingH3Size || "1.75rem" },
      { tag: "h4", size: settings.headingH4Size || "1.5rem" },
      { tag: "h5", size: settings.headingH5Size || "1.25rem" },
      { tag: "h6", size: settings.headingH6Size || "1rem" },
    ];

    headingSizes.forEach(({ tag, size }) => {
      css += `${tag},\n.${tag},\n[class*="${tag}"] {\n`;
      css += `  font-family: ${headingFont} !important;\n`;
      css += `  font-size: ${size} !important;\n`;
      css += `  font-weight: ${settings.headingFontWeight || "700"} !important;\n`;
      css += `  line-height: ${settings.headingLineHeight || "1.2"} !important;\n`;
      css += `  letter-spacing: ${settings.headingLetterSpacing || "0em"} !important;\n`;
      if (settings.headingColor)
        css += `  color: ${settings.headingColor} !important;\n`;
      if (settings.headingTextTransform && settings.headingTextTransform !== "none")
        css += `  text-transform: ${settings.headingTextTransform} !important;\n`;
      css += `}\n\n`;
    });
  }

  // Button overrides
  if (buttonFont) {
    css += `/* ─── Button Typography ─── */\n`;
    css += `button,\n.btn,\n[class*="btn"],\n[class*="button"],\ninput[type="submit"],\ninput[type="button"] {\n`;
    css += `  font-family: ${buttonFont} !important;\n`;
    css += `  font-size: ${settings.buttonFontSize || "1rem"} !important;\n`;
    css += `  font-weight: ${settings.buttonFontWeight || "600"} !important;\n`;
    css += `  line-height: ${settings.buttonLineHeight || "1.4"} !important;\n`;
    css += `  letter-spacing: ${settings.buttonLetterSpacing || "0.05em"} !important;\n`;
    if (settings.buttonTextTransform)
      css += `  text-transform: ${settings.buttonTextTransform} !important;\n`;
    css += `}\n\n`;
  }

  // Nav overrides
  if (navFont) {
    css += `/* ─── Navigation Typography ─── */\n`;
    css += `nav, nav *, .nav, .nav *, .navigation, .navigation *, header a {\n`;
    css += `  font-family: ${navFont} !important;\n`;
    css += `  font-size: ${settings.navFontSize || "0.875rem"} !important;\n`;
    css += `  font-weight: ${settings.navFontWeight || "500"} !important;\n`;
    css += `  letter-spacing: ${settings.navLetterSpacing || "0.05em"} !important;\n`;
    if (settings.navTextTransform)
      css += `  text-transform: ${settings.navTextTransform} !important;\n`;
    css += `}\n\n`;
  }

  // Custom CSS
  if (settings.customCSS) {
    css += `/* ─── Custom CSS ─── */\n`;
    css += settings.customCSS + "\n";
  }

  return css;
}

// ─── Theme Asset Injection ─────────────────────────────────────────────────────

export async function injectFontCSS(
  admin: any,
  themeId: string,
  css: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await admin.graphql(
      `#graphql
      mutation themeFilesUpsert($themeId: ID!, $files: [OnlineStoreThemeFilesUpsertFileInput!]!) {
        themeFilesUpsert(themeId: $themeId, files: $files) {
          upsertedThemeFiles {
            filename
          }
          userErrors {
            code
            filename
            message
          }
        }
      }`,
      {
        variables: {
          themeId: `gid://shopify/OnlineStoreTheme/${themeId}`,
          files: [
            {
              filename: "assets/font-vault.css",
              body: {
                type: "TEXT",
                value: css,
              },
            },
          ],
        },
      }
    );

    const data = await response.json();
    const errors = data?.data?.themeFilesUpsert?.userErrors;

    if (errors && errors.length > 0) {
      return { success: false, error: errors[0].message };
    }

    // Inject the link tag into theme.liquid
    await injectLinkTagIntoTheme(admin, themeId);

    return { success: true };
  } catch (error) {
    console.error("Error injecting font CSS:", error);
    return { success: false, error: String(error) };
  }
}

async function injectLinkTagIntoTheme(admin: any, themeId: string) {
  // Get current theme.liquid content
  const getResponse = await admin.graphql(
    `#graphql
    query getThemeFile($themeId: ID!) {
      theme(id: $themeId) {
        files(filenames: ["layout/theme.liquid"]) {
          nodes {
            filename
            body {
              ... on OnlineStoreThemeFileBodyText {
                content
              }
            }
          }
        }
      }
    }`,
    {
      variables: {
        themeId: `gid://shopify/OnlineStoreTheme/${themeId}`,
      },
    }
  );

  const getData = await getResponse.json();
  const themeFile = getData?.data?.theme?.files?.nodes?.[0];

  if (!themeFile?.body?.content) return;

  let content = themeFile.body.content;
  const linkTag = `  {{ 'font-vault.css' | asset_url | stylesheet_tag }}`;
  const marker = `<!-- font-vault -->`;

  // Remove existing injection if present
  if (content.includes(marker)) {
    const regex = new RegExp(`\\s*${marker}[\\s\\S]*?${marker}\\s*`, "g");
    content = content.replace(regex, "\n");
  }

  // Inject before closing </head>
  const headCloseTag = "</head>";
  if (content.includes(headCloseTag)) {
    content = content.replace(
      headCloseTag,
      `  ${marker}\n${linkTag}\n  ${marker}\n${headCloseTag}`
    );
  }

  // Update theme.liquid
  await admin.graphql(
    `#graphql
    mutation themeFilesUpsert($themeId: ID!, $files: [OnlineStoreThemeFilesUpsertFileInput!]!) {
      themeFilesUpsert(themeId: $themeId, files: $files) {
        upsertedThemeFiles {
          filename
        }
        userErrors {
          code
          filename
          message
        }
      }
    }`,
    {
      variables: {
        themeId: `gid://shopify/OnlineStoreTheme/${themeId}`,
        files: [
          {
            filename: "layout/theme.liquid",
            body: {
              type: "TEXT",
              value: content,
            },
          },
        ],
      },
    }
  );
}

export async function removeFontCSS(admin: any, themeId: string) {
  // Remove font-vault.css asset
  await admin.graphql(
    `#graphql
    mutation themeFilesDelete($themeId: ID!, $files: [String!]!) {
      themeFilesDelete(themeId: $themeId, files: $files) {
        deletedThemeFiles {
          filename
        }
        userErrors {
          code
          filename
          message
        }
      }
    }`,
    {
      variables: {
        themeId: `gid://shopify/OnlineStoreTheme/${themeId}`,
        files: ["assets/font-vault.css"],
      },
    }
  );
}

export async function getThemes(admin: any) {
  const response = await admin.graphql(
    `#graphql
    query getThemes {
      themes(first: 20) {
        nodes {
          id
          name
          role
          processing
        }
      }
    }`
  );

  const data = await response.json();
  return data?.data?.themes?.nodes || [];
}

export async function uploadFontToShopify(
  admin: any,
  themeId: string,
  fileName: string,
  fileContent: string // base64 encoded
): Promise<string> {
  const response = await admin.graphql(
    `#graphql
    mutation themeFilesUpsert($themeId: ID!, $files: [OnlineStoreThemeFilesUpsertFileInput!]!) {
      themeFilesUpsert(themeId: $themeId, files: $files) {
        upsertedThemeFiles {
          filename
        }
        userErrors {
          code
          filename
          message
        }
      }
    }`,
    {
      variables: {
        themeId: `gid://shopify/OnlineStoreTheme/${themeId}`,
        files: [
          {
            filename: `assets/${fileName}`,
            body: {
              type: "BASE64",
              value: fileContent,
            },
          },
        ],
      },
    }
  );

  const data = await response.json();
  const errors = data?.data?.themeFilesUpsert?.userErrors;
  if (errors?.length > 0) throw new Error(errors[0].message);

  return `assets/${fileName}`;
}

// ─── Helper Utilities ─────────────────────────────────────────────────────────

function getFormatString(format: string): string {
  const formats: Record<string, string> = {
    woff2: "woff2",
    woff: "woff",
    ttf: "truetype",
    otf: "opentype",
  };
  return formats[format.toLowerCase()] || format;
}

export function getFontFamiliesFromFonts(fonts: FontFile[]): string[] {
  const families = new Set<string>();
  fonts.forEach((f) => families.add(f.family));
  return Array.from(families).sort();
}

export function validateFontFile(fileName: string): {
  valid: boolean;
  format: string;
  error?: string;
} {
  const ext = fileName.split(".").pop()?.toLowerCase() || "";
  const allowed = ["woff2", "woff", "ttf", "otf"];

  if (!allowed.includes(ext)) {
    return {
      valid: false,
      format: "",
      error: `Invalid format. Allowed: ${allowed.join(", ")}`,
    };
  }

  return { valid: true, format: ext };
}
