import { useLoaderData, useFetcher } from "@remix-run/react";
import type { LoaderFunctionArgs, ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  BlockStack,
  InlineStack,
  Badge,
  Banner,
  Select,
  Divider,
  Box,
  DataTable,
  List,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import {
  getFonts,
  getTypographySettings,
  getThemes,
  generateTypographyCSS,
  injectFontCSS,
  removeFontCSS,
} from "../lib/font.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const [fonts, settings, themes] = await Promise.all([
    getFonts(shop),
    getTypographySettings(shop),
    getThemes(admin),
  ]);

  const activeTheme = themes.find((t: any) => t.role === "MAIN");

  return json({
    shop,
    fonts,
    settings,
    themes,
    activeTheme,
    activeThemeId: activeTheme?.id?.replace("gid://shopify/OnlineStoreTheme/", ""),
  });
}

export async function action({ request }: ActionFunctionArgs) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const formData = await request.formData();
  const intent = formData.get("intent") as string;

  if (intent === "regenerate-css") {
    const themeId = formData.get("themeId") as string;
    const fonts = await getFonts(shop);
    const settings = await import("../shopify.server").then(m => m.prisma.typographySettings.findUnique({ where: { shop } }));

    if (!settings) {
      return json({ success: false, error: "No typography settings found. Configure them in the Typography page first." });
    }

    const css = generateTypographyCSS(settings, fonts as any);
    const result = await injectFontCSS(admin, themeId, css);

    if (!result.success) return json({ success: false, error: result.error });
    return json({ success: true, action: "regenerated" });
  }

  if (intent === "remove-css") {
    const themeId = formData.get("themeId") as string;
    await removeFontCSS(admin, themeId);
    return json({ success: true, action: "removed" });
  }

  return json({ success: false, error: "Unknown intent" });
}

export default function SettingsPage() {
  const { shop, fonts, settings, themes, activeTheme, activeThemeId } =
    useLoaderData<typeof loader>();
  const fetcher = useFetcher<any>();
  const isSubmitting = fetcher.state !== "idle";

  const themeOptions = themes.map((t: any) => ({
    label: `${t.name}${t.role === "MAIN" ? " (Active)" : ""}`,
    value: t.id.replace("gid://shopify/OnlineStoreTheme/", ""),
  }));

  const handleAction = (intent: string) => {
    const formData = new FormData();
    formData.append("intent", intent);
    formData.append("themeId", activeThemeId || "");
    fetcher.submit(formData, { method: "post" });
  };

  return (
    <Page
      title="App Settings"
      subtitle="Manage Font Vault configuration and theme injection"
      backAction={{ content: "Dashboard", url: "/app" }}
    >
      <BlockStack gap="500">
        {fetcher.data?.action === "regenerated" && (
          <Banner tone="success" title="CSS regenerated and applied to theme" />
        )}
        {fetcher.data?.action === "removed" && (
          <Banner tone="info" title="Font Vault CSS removed from theme">
            <p>Your theme typography has been restored to its defaults.</p>
          </Banner>
        )}
        {fetcher.data?.error && (
          <Banner tone="critical" title="Error">{fetcher.data.error}</Banner>
        )}

        <Layout>
          <Layout.Section>
            {/* Status Overview */}
            <Card>
              <BlockStack gap="400">
                <InlineStack align="space-between">
                  <Text as="h2" variant="headingLg">Status Overview</Text>
                  <Badge tone={settings?.isActive ? "success" : "attention"}>
                    {settings?.isActive ? "Active" : "Inactive"}
                  </Badge>
                </InlineStack>
                <DataTable
                  columnContentTypes={["text", "text"]}
                  headings={["Setting", "Value"]}
                  rows={[
                    ["Store", shop],
                    ["Active Theme", activeTheme?.name || "—"],
                    ["Fonts Uploaded", String(fonts.length)],
                    ["Typography Override", settings?.isActive ? "Active" : "Inactive"],
                    ["Heading Font", settings?.headingFontFamily || "Theme default"],
                    ["Body Font", settings?.bodyFontFamily || "Theme default"],
                    ["Button Font", settings?.buttonFontFamily || "Theme default"],
                  ]}
                />
              </BlockStack>
            </Card>

            {/* Theme Management */}
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">Theme Management</Text>
                <Text as="p" variant="bodyMd" tone="subdued">
                  Font Vault injects a CSS file (<code>assets/font-vault.css</code>) into your theme
                  and adds a stylesheet link in <code>layout/theme.liquid</code>.
                </Text>

                <Box
                  background="bg-surface-secondary"
                  padding="400"
                  borderRadius="200"
                >
                  <BlockStack gap="200">
                    <Text as="p" variant="bodyMd" fontWeight="semibold">What gets modified:</Text>
                    <List type="bullet">
                      <List.Item><code>assets/font-vault.css</code> — Generated CSS with @font-face rules and typography overrides</List.Item>
                      <List.Item><code>layout/theme.liquid</code> — A stylesheet link tag is added inside <code>&lt;head&gt;</code></List.Item>
                    </List>
                  </BlockStack>
                </Box>

                <Divider />

                <InlineStack gap="300" wrap>
                  <Button
                    onClick={() => handleAction("regenerate-css")}
                    loading={isSubmitting}
                    disabled={!activeThemeId || !settings}
                  >
                    Regenerate & Re-inject CSS
                  </Button>
                  <Button
                    tone="critical"
                    onClick={() => handleAction("remove-css")}
                    loading={isSubmitting}
                    disabled={!activeThemeId}
                  >
                    Remove Font Vault from Theme
                  </Button>
                </InlineStack>
              </BlockStack>
            </Card>

            {/* Available Themes */}
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">Your Themes</Text>
                <DataTable
                  columnContentTypes={["text", "text", "text"]}
                  headings={["Theme Name", "Role", "Status"]}
                  rows={themes.map((t: any) => [
                    t.name,
                    t.role,
                    <Badge tone={t.role === "MAIN" ? "success" : "default"}>
                      {t.role === "MAIN" ? "Live" : "Development"}
                    </Badge>,
                  ])}
                />
              </BlockStack>
            </Card>
          </Layout.Section>

          <Layout.Section variant="oneThird">
            <BlockStack gap="400">
              {/* Help */}
              <Card>
                <BlockStack gap="300">
                  <Text as="h3" variant="headingMd">📋 Setup Checklist</Text>
                  <BlockStack gap="200">
                    {[
                      { done: fonts.length > 0, text: "Upload at least one font" },
                      { done: !!settings?.headingFontFamily || !!settings?.bodyFontFamily, text: "Configure typography settings" },
                      { done: !!settings?.isActive, text: "Apply to your theme" },
                    ].map(({ done, text }) => (
                      <InlineStack key={text} gap="200" blockAlign="center">
                        <Text as="span" variant="bodySm">{done ? "✅" : "⬜"}</Text>
                        <Text as="span" variant="bodySm" tone={done ? "success" : "subdued"}>{text}</Text>
                      </InlineStack>
                    ))}
                  </BlockStack>
                </BlockStack>
              </Card>

              {/* Required Scopes */}
              <Card>
                <BlockStack gap="300">
                  <Text as="h3" variant="headingMd">🔑 API Scopes</Text>
                  <Text as="p" variant="bodySm" tone="subdued">Required permissions:</Text>
                  {["read_themes", "write_themes", "read_files", "write_files"].map(scope => (
                    <InlineStack key={scope} gap="200" blockAlign="center">
                      <Badge tone="success">✓</Badge>
                      <Text as="span" variant="bodySm"><code>{scope}</code></Text>
                    </InlineStack>
                  ))}
                </BlockStack>
              </Card>

              {/* Developer Info */}
              <Card>
                <BlockStack gap="300">
                  <Text as="h3" variant="headingMd">💻 Developer Info</Text>
                  <Text as="p" variant="bodySm" tone="subdued">
                    Font files are uploaded as theme assets. The CSS file references them
                    using Shopify's <code>asset_url</code> Liquid filter to ensure proper CDN delivery.
                  </Text>
                  <Text as="p" variant="bodySm" tone="subdued">
                    CSS is applied with <code>!important</code> on key properties to ensure override of theme defaults.
                  </Text>
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}
