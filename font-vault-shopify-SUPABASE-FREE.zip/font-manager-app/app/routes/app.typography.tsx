import { useState, useEffect } from "react";
import { useLoaderData, useFetcher, useSearchParams } from "@remix-run/react";
import type { LoaderFunctionArgs, ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  BlockStack,
  InlineStack,
  Badge,
  Banner,
  Select,
  TextField,
  RangeSlider,
  Divider,
  Box,
  Tabs,
  Grid,
  Tooltip,
  Icon,
  Checkbox,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import {
  getFonts,
  getTypographySettings,
  upsertTypographySettings,
  getThemes,
  generateTypographyCSS,
  injectFontCSS,
  getFontFamiliesFromFonts,
} from "../lib/font.server";
import type { TypographySettings } from "@prisma/client";

export async function loader({ request }: LoaderFunctionArgs) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const [fonts, settings, themes] = await Promise.all([
    getFonts(shop),
    getTypographySettings(shop),
    getThemes(admin),
  ]);
  const activeTheme = themes.find((t: any) => t.role === "MAIN");
  return json({
    fonts,
    settings,
    themes,
    activeTheme,
    activeThemeId: activeTheme?.id?.replace("gid://shopify/OnlineStoreTheme/", ""),
  });
}

export async function action({ request }: ActionFunctionArgs) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const formData = await request.formData();
  const intent = formData.get("intent") as string;

  if (intent === "save") {
    const settings: any = {};
    for (const [key, value] of formData.entries()) {
      if (key !== "intent" && key !== "themeId") {
        settings[key] = value as string;
      }
    }
    settings.isActive = settings.isActive === "true";

    await upsertTypographySettings(shop, settings);
    return json({ success: true, action: "saved" });
  }

  if (intent === "apply") {
    const themeId = formData.get("themeId") as string;
    const settingsData: any = {};
    for (const [key, value] of formData.entries()) {
      if (key !== "intent" && key !== "themeId") {
        settingsData[key] = value as string;
      }
    }
    settingsData.isActive = true;

    // Save settings
    const savedSettings = await upsertTypographySettings(shop, settingsData);

    // Generate and inject CSS
    const fonts = await getFonts(shop);
    const css = generateTypographyCSS(savedSettings, fonts as any);
    const result = await injectFontCSS(admin, themeId, css);

    if (!result.success) {
      return json({ success: false, error: result.error });
    }

    return json({ success: true, action: "applied", css });
  }

  if (intent === "deactivate") {
    await upsertTypographySettings(shop, { isActive: false });
    return json({ success: true, action: "deactivated" });
  }

  return json({ success: false, error: "Unknown intent" });
}

const FONT_SIZE_OPTIONS = [
  "0.75rem", "0.875rem", "1rem", "1.125rem", "1.25rem", "1.5rem",
  "1.75rem", "2rem", "2.25rem", "2.5rem", "3rem", "3.5rem", "4rem",
].map(s => ({ label: s, value: s }));

const FONT_WEIGHT_OPTIONS = [
  { label: "100 — Thin", value: "100" },
  { label: "200 — Extra Light", value: "200" },
  { label: "300 — Light", value: "300" },
  { label: "400 — Regular", value: "400" },
  { label: "500 — Medium", value: "500" },
  { label: "600 — Semi Bold", value: "600" },
  { label: "700 — Bold", value: "700" },
  { label: "800 — Extra Bold", value: "800" },
  { label: "900 — Black", value: "900" },
];

const TEXT_TRANSFORM_OPTIONS = [
  { label: "None", value: "none" },
  { label: "Uppercase", value: "uppercase" },
  { label: "Lowercase", value: "lowercase" },
  { label: "Capitalize", value: "capitalize" },
];

const PREVIEW_SAMPLES = {
  heading: "Bold Statement Heading",
  body: "The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs.",
  button: "Add to Cart",
  nav: "Home  Shop  About  Contact",
  meta: "In stock — Usually ships in 2-3 days",
};

export default function TypographyPage() {
  const { fonts, settings, themes, activeTheme, activeThemeId } =
    useLoaderData<typeof loader>();
  const fetcher = useFetcher<any>();
  const [searchParams] = useSearchParams();
  const [selectedTab, setSelectedTab] = useState(0);

  const fontFamilies = getFontFamiliesFromFonts(fonts as any);
  const fontOptions = [
    { label: "— Use theme default —", value: "" },
    ...fontFamilies.map(f => ({ label: f, value: f })),
  ];

  const themeOptions = themes.map((t: any) => ({
    label: `${t.name}${t.role === "MAIN" ? " (Active)" : ""}`,
    value: t.id.replace("gid://shopify/OnlineStoreTheme/", ""),
  }));

  // Form state
  const s = settings as TypographySettings | null;
  const [selectedThemeId, setSelectedThemeId] = useState(activeThemeId || "");

  // Heading
  const [headingFont, setHeadingFont] = useState(s?.headingFontFamily || "");
  const [headingSize, setHeadingSize] = useState(s?.headingFontSize || "2.5rem");
  const [headingH2, setHeadingH2] = useState(s?.headingH2Size || "2rem");
  const [headingH3, setHeadingH3] = useState(s?.headingH3Size || "1.75rem");
  const [headingWeight, setHeadingWeight] = useState(s?.headingFontWeight || "700");
  const [headingLineHeight, setHeadingLineHeight] = useState(s?.headingLineHeight || "1.2");
  const [headingLetterSpacing, setHeadingLetterSpacing] = useState(s?.headingLetterSpacing || "0em");
  const [headingColor, setHeadingColor] = useState(s?.headingColor || "#000000");
  const [headingTransform, setHeadingTransform] = useState(s?.headingTextTransform || "none");

  // Body
  const [bodyFont, setBodyFont] = useState(s?.bodyFontFamily || "");
  const [bodySize, setBodySize] = useState(s?.bodyFontSize || "1rem");
  const [bodyWeight, setBodyWeight] = useState(s?.bodyFontWeight || "400");
  const [bodyLineHeight, setBodyLineHeight] = useState(s?.bodyLineHeight || "1.6");
  const [bodyLetterSpacing, setBodyLetterSpacing] = useState(s?.bodyLetterSpacing || "0em");
  const [bodyColor, setBodyColor] = useState(s?.bodyColor || "#333333");
  const [bodyTransform, setBodyTransform] = useState(s?.bodyTextTransform || "none");

  // Button
  const [buttonFont, setButtonFont] = useState(s?.buttonFontFamily || "");
  const [buttonSize, setButtonSize] = useState(s?.buttonFontSize || "1rem");
  const [buttonWeight, setButtonWeight] = useState(s?.buttonFontWeight || "600");
  const [buttonLetterSpacing, setButtonLetterSpacing] = useState(s?.buttonLetterSpacing || "0.05em");
  const [buttonTransform, setButtonTransform] = useState(s?.buttonTextTransform || "uppercase");

  // Nav
  const [navFont, setNavFont] = useState(s?.navFontFamily || "");
  const [navSize, setNavSize] = useState(s?.navFontSize || "0.875rem");
  const [navWeight, setNavWeight] = useState(s?.navFontWeight || "500");
  const [navLetterSpacing, setNavLetterSpacing] = useState(s?.navLetterSpacing || "0.05em");
  const [navTransform, setNavTransform] = useState(s?.navTextTransform || "none");

  // Custom CSS
  const [customCSS, setCustomCSS] = useState(s?.customCSS || "");

  const isSubmitting = fetcher.state !== "idle";

  // Apply URL param for heading font (from font library)
  useEffect(() => {
    const hf = searchParams.get("headingFont");
    if (hf) setHeadingFont(hf);
  }, [searchParams]);

  const buildFormData = (intentValue: string) => {
    const fd = new FormData();
    fd.append("intent", intentValue);
    fd.append("themeId", selectedThemeId);
    fd.append("headingFontFamily", headingFont);
    fd.append("headingFontSize", headingSize);
    fd.append("headingH2Size", headingH2);
    fd.append("headingH3Size", headingH3);
    fd.append("headingFontWeight", headingWeight);
    fd.append("headingLineHeight", headingLineHeight);
    fd.append("headingLetterSpacing", headingLetterSpacing);
    fd.append("headingColor", headingColor);
    fd.append("headingTextTransform", headingTransform);
    fd.append("bodyFontFamily", bodyFont);
    fd.append("bodyFontSize", bodySize);
    fd.append("bodyFontWeight", bodyWeight);
    fd.append("bodyLineHeight", bodyLineHeight);
    fd.append("bodyLetterSpacing", bodyLetterSpacing);
    fd.append("bodyColor", bodyColor);
    fd.append("bodyTextTransform", bodyTransform);
    fd.append("buttonFontFamily", buttonFont);
    fd.append("buttonFontSize", buttonSize);
    fd.append("buttonFontWeight", buttonWeight);
    fd.append("buttonLetterSpacing", buttonLetterSpacing);
    fd.append("buttonTextTransform", buttonTransform);
    fd.append("navFontFamily", navFont);
    fd.append("navFontSize", navSize);
    fd.append("navFontWeight", navWeight);
    fd.append("navLetterSpacing", navLetterSpacing);
    fd.append("navTextTransform", navTransform);
    fd.append("customCSS", customCSS);
    fd.append("isActive", intentValue === "apply" ? "true" : String(s?.isActive || false));
    return fd;
  };

  const tabs = [
    { id: "headings", content: "Headings" },
    { id: "body", content: "Body Text" },
    { id: "buttons", content: "Buttons" },
    { id: "navigation", content: "Navigation" },
    { id: "custom", content: "Custom CSS" },
    { id: "preview", content: "Live Preview" },
  ];

  const TypographyControl = ({
    label, children, preview
  }: { label: string; children: React.ReactNode; preview?: React.ReactNode }) => (
    <Box borderWidth="025" borderColor="border" borderRadius="200" padding="400">
      <BlockStack gap="300">
        <Text as="h4" variant="headingSm" tone="subdued">{label}</Text>
        {children}
        {preview && (
          <>
            <Divider />
            <Box background="bg-surface-secondary" padding="300" borderRadius="100">
              {preview}
            </Box>
          </>
        )}
      </BlockStack>
    </Box>
  );

  return (
    <Page
      title="Typography Settings"
      subtitle="Control fonts, sizes, weights and spacing across your store"
      primaryAction={{
        content: isSubmitting ? "Applying..." : "Apply to Theme",
        onAction: () => fetcher.submit(buildFormData("apply"), { method: "post" }),
        loading: isSubmitting,
        disabled: !selectedThemeId,
        tone: "success",
      }}
      secondaryActions={[
        {
          content: "Save Draft",
          onAction: () => fetcher.submit(buildFormData("save"), { method: "post" }),
          disabled: isSubmitting,
        },
        ...(s?.isActive ? [{
          content: "Deactivate",
          onAction: () => fetcher.submit(new FormData(), { method: "post" }),
          destructive: true,
        }] : []),
      ]}
      backAction={{ content: "Dashboard", url: "/app" }}
    >
      <BlockStack gap="500">
        {/* Status Banner */}
        {fetcher.data?.action === "applied" && (
          <Banner tone="success" title="Typography applied to your theme!">
            <p>Your custom fonts are now live. Visit your store to see the changes.</p>
          </Banner>
        )}
        {fetcher.data?.action === "saved" && (
          <Banner tone="info" title="Settings saved as draft">
            <p>Click "Apply to Theme" to push changes to your live store.</p>
          </Banner>
        )}
        {fetcher.data?.error && (
          <Banner tone="critical" title="Error applying typography">
            <p>{fetcher.data.error}</p>
          </Banner>
        )}

        {fonts.length === 0 && (
          <Banner
            tone="warning"
            title="No fonts uploaded yet"
            action={{ content: "Upload Fonts", url: "/app/fonts" }}
          >
            <p>Upload custom fonts first to use them in typography settings.</p>
          </Banner>
        )}

        <Layout>
          <Layout.Section>
            {/* Theme Selector */}
            <Card>
              <BlockStack gap="300">
                <InlineStack align="space-between" blockAlign="center">
                  <Text as="h2" variant="headingMd">Target Theme</Text>
                  {s?.isActive && <Badge tone="success">Live</Badge>}
                </InlineStack>
                <Select
                  label="Apply typography to:"
                  options={themeOptions}
                  value={selectedThemeId}
                  onChange={setSelectedThemeId}
                />
              </BlockStack>
            </Card>

            {/* Typography Tabs */}
            <Card>
              <Tabs tabs={tabs} selected={selectedTab} onSelect={setSelectedTab}>
                {/* HEADINGS TAB */}
                {selectedTab === 0 && (
                  <Box padding="400">
                    <BlockStack gap="400">
                      <TypographyControl
                        label="Heading Font Family"
                        preview={
                          <div style={{ fontFamily: headingFont ? `"${headingFont}", sans-serif` : "inherit" }}>
                            <div style={{ fontSize: headingSize, fontWeight: headingWeight, lineHeight: headingLineHeight, letterSpacing: headingLetterSpacing, color: headingColor, textTransform: headingTransform as any }}>
                              {PREVIEW_SAMPLES.heading}
                            </div>
                          </div>
                        }
                      >
                        <Select label="Font Family" options={fontOptions} value={headingFont} onChange={setHeadingFont} />
                      </TypographyControl>

                      <Grid>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="H1 Size" options={FONT_SIZE_OPTIONS} value={headingSize} onChange={setHeadingSize} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="H2 Size" options={FONT_SIZE_OPTIONS} value={headingH2} onChange={setHeadingH2} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="H3 Size" options={FONT_SIZE_OPTIONS} value={headingH3} onChange={setHeadingH3} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="Font Weight" options={FONT_WEIGHT_OPTIONS} value={headingWeight} onChange={setHeadingWeight} />
                        </Grid.Cell>
                      </Grid>

                      <Grid>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <TextField
                            label="Line Height"
                            value={headingLineHeight}
                            onChange={setHeadingLineHeight}
                            placeholder="1.2"
                            helpText="e.g. 1.2, 1.5, 1.8"
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <TextField
                            label="Letter Spacing"
                            value={headingLetterSpacing}
                            onChange={setHeadingLetterSpacing}
                            placeholder="0em"
                            helpText="e.g. 0em, 0.05em, -0.02em"
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 4, xl: 4 }}>
                          <TextField
                            label="Text Color"
                            value={headingColor}
                            onChange={setHeadingColor}
                            placeholder="#000000"
                            prefix={<div style={{ width: 16, height: 16, borderRadius: 3, background: headingColor, border: "1px solid #ccc" }} />}
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 4, xl: 4 }}>
                          <Select
                            label="Text Transform"
                            options={TEXT_TRANSFORM_OPTIONS}
                            value={headingTransform}
                            onChange={setHeadingTransform}
                          />
                        </Grid.Cell>
                      </Grid>
                    </BlockStack>
                  </Box>
                )}

                {/* BODY TEXT TAB */}
                {selectedTab === 1 && (
                  <Box padding="400">
                    <BlockStack gap="400">
                      <TypographyControl
                        label="Body Font Family"
                        preview={
                          <div style={{
                            fontFamily: bodyFont ? `"${bodyFont}", sans-serif` : "inherit",
                            fontSize: bodySize,
                            fontWeight: bodyWeight,
                            lineHeight: bodyLineHeight,
                            letterSpacing: bodyLetterSpacing,
                            color: bodyColor,
                          }}>
                            {PREVIEW_SAMPLES.body}
                          </div>
                        }
                      >
                        <Select label="Font Family" options={fontOptions} value={bodyFont} onChange={setBodyFont} />
                      </TypographyControl>

                      <Grid>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="Font Size" options={FONT_SIZE_OPTIONS} value={bodySize} onChange={setBodySize} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="Font Weight" options={FONT_WEIGHT_OPTIONS} value={bodyWeight} onChange={setBodyWeight} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <TextField
                            label="Line Height"
                            value={bodyLineHeight}
                            onChange={setBodyLineHeight}
                            placeholder="1.6"
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <TextField
                            label="Letter Spacing"
                            value={bodyLetterSpacing}
                            onChange={setBodyLetterSpacing}
                            placeholder="0em"
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <TextField
                            label="Text Color"
                            value={bodyColor}
                            onChange={setBodyColor}
                            placeholder="#333333"
                            prefix={<div style={{ width: 16, height: 16, borderRadius: 3, background: bodyColor, border: "1px solid #ccc" }} />}
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select
                            label="Text Transform"
                            options={TEXT_TRANSFORM_OPTIONS}
                            value={bodyTransform}
                            onChange={setBodyTransform}
                          />
                        </Grid.Cell>
                      </Grid>
                    </BlockStack>
                  </Box>
                )}

                {/* BUTTONS TAB */}
                {selectedTab === 2 && (
                  <Box padding="400">
                    <BlockStack gap="400">
                      <TypographyControl
                        label="Button Font"
                        preview={
                          <div>
                            <button style={{
                              fontFamily: buttonFont ? `"${buttonFont}", sans-serif` : "inherit",
                              fontSize: buttonSize,
                              fontWeight: buttonWeight,
                              letterSpacing: buttonLetterSpacing,
                              textTransform: buttonTransform as any,
                              padding: "12px 24px",
                              background: "#000",
                              color: "#fff",
                              border: "none",
                              borderRadius: "4px",
                              cursor: "pointer",
                            }}>
                              {PREVIEW_SAMPLES.button}
                            </button>
                          </div>
                        }
                      >
                        <Select label="Font Family" options={fontOptions} value={buttonFont} onChange={setButtonFont} />
                      </TypographyControl>

                      <Grid>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="Font Size" options={FONT_SIZE_OPTIONS} value={buttonSize} onChange={setButtonSize} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="Font Weight" options={FONT_WEIGHT_OPTIONS} value={buttonWeight} onChange={setButtonWeight} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <TextField
                            label="Letter Spacing"
                            value={buttonLetterSpacing}
                            onChange={setButtonLetterSpacing}
                            placeholder="0.05em"
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select
                            label="Text Transform"
                            options={TEXT_TRANSFORM_OPTIONS}
                            value={buttonTransform}
                            onChange={setButtonTransform}
                          />
                        </Grid.Cell>
                      </Grid>
                    </BlockStack>
                  </Box>
                )}

                {/* NAVIGATION TAB */}
                {selectedTab === 3 && (
                  <Box padding="400">
                    <BlockStack gap="400">
                      <TypographyControl
                        label="Navigation Font"
                        preview={
                          <div style={{
                            fontFamily: navFont ? `"${navFont}", sans-serif` : "inherit",
                            fontSize: navSize,
                            fontWeight: navWeight,
                            letterSpacing: navLetterSpacing,
                            textTransform: navTransform as any,
                          }}>
                            {PREVIEW_SAMPLES.nav}
                          </div>
                        }
                      >
                        <Select label="Font Family" options={fontOptions} value={navFont} onChange={setNavFont} />
                      </TypographyControl>

                      <Grid>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="Font Size" options={FONT_SIZE_OPTIONS} value={navSize} onChange={setNavSize} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select label="Font Weight" options={FONT_WEIGHT_OPTIONS} value={navWeight} onChange={setNavWeight} />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <TextField
                            label="Letter Spacing"
                            value={navLetterSpacing}
                            onChange={setNavLetterSpacing}
                            placeholder="0.05em"
                            autoComplete="off"
                          />
                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                          <Select
                            label="Text Transform"
                            options={TEXT_TRANSFORM_OPTIONS}
                            value={navTransform}
                            onChange={setNavTransform}
                          />
                        </Grid.Cell>
                      </Grid>
                    </BlockStack>
                  </Box>
                )}

                {/* CUSTOM CSS TAB */}
                {selectedTab === 4 && (
                  <Box padding="400">
                    <BlockStack gap="400">
                      <Banner tone="info" title="Advanced: Custom CSS">
                        <p>Write raw CSS to override anything Font Vault doesn't cover. This is appended after the generated styles.</p>
                      </Banner>
                      <TextField
                        label="Custom CSS"
                        value={customCSS}
                        onChange={setCustomCSS}
                        multiline={15}
                        placeholder={`/* Target specific elements */\n.product-title {\n  font-family: "My Font", sans-serif;\n  font-size: 1.5rem;\n}\n\n/* Override theme variables */\n:root {\n  --font-size-base: 16px;\n}`}
                        monospaced
                        autoComplete="off"
                      />
                    </BlockStack>
                  </Box>
                )}

                {/* LIVE PREVIEW TAB */}
                {selectedTab === 5 && (
                  <Box padding="400">
                    <BlockStack gap="400">
                      <Banner tone="info" title="Preview Mode">
                        <p>This is a live CSS preview. Save and apply settings to see them in your actual store.</p>
                      </Banner>

                      {/* Mock Store Preview */}
                      <Box
                        background="bg-surface"
                        borderWidth="025"
                        borderColor="border"
                        borderRadius="200"
                        padding="600"
                      >
                        {/* Nav */}
                        <div style={{
                          fontFamily: navFont ? `"${navFont}", sans-serif` : "inherit",
                          fontSize: navSize,
                          fontWeight: navWeight,
                          letterSpacing: navLetterSpacing,
                          textTransform: navTransform as any,
                          borderBottom: "1px solid #eee",
                          paddingBottom: "12px",
                          marginBottom: "24px",
                          display: "flex",
                          gap: "24px",
                        }}>
                          <span>Home</span><span>Shop</span><span>About</span><span>Contact</span>
                        </div>

                        {/* H1 */}
                        <div style={{
                          fontFamily: headingFont ? `"${headingFont}", sans-serif` : "inherit",
                          fontSize: headingSize,
                          fontWeight: headingWeight,
                          lineHeight: headingLineHeight,
                          letterSpacing: headingLetterSpacing,
                          color: headingColor,
                          textTransform: headingTransform as any,
                          marginBottom: "16px",
                        }}>
                          {PREVIEW_SAMPLES.heading}
                        </div>

                        {/* Body */}
                        <div style={{
                          fontFamily: bodyFont ? `"${bodyFont}", sans-serif` : "inherit",
                          fontSize: bodySize,
                          fontWeight: bodyWeight,
                          lineHeight: bodyLineHeight,
                          letterSpacing: bodyLetterSpacing,
                          color: bodyColor,
                          marginBottom: "24px",
                        }}>
                          {PREVIEW_SAMPLES.body}
                        </div>

                        {/* H2 */}
                        <div style={{
                          fontFamily: headingFont ? `"${headingFont}", sans-serif` : "inherit",
                          fontSize: headingH2,
                          fontWeight: headingWeight,
                          lineHeight: headingLineHeight,
                          color: headingColor,
                          marginBottom: "12px",
                        }}>
                          Featured Products
                        </div>

                        <div style={{
                          fontFamily: bodyFont ? `"${bodyFont}", sans-serif` : "inherit",
                          fontSize: bodySize,
                          color: bodyColor,
                          marginBottom: "20px",
                        }}>
                          Discover our curated selection of premium products, handpicked for quality and style.
                        </div>

                        {/* Button */}
                        <button style={{
                          fontFamily: buttonFont ? `"${buttonFont}", sans-serif` : "inherit",
                          fontSize: buttonSize,
                          fontWeight: buttonWeight,
                          letterSpacing: buttonLetterSpacing,
                          textTransform: buttonTransform as any,
                          padding: "14px 28px",
                          background: "#222",
                          color: "#fff",
                          border: "none",
                          borderRadius: "4px",
                          cursor: "pointer",
                        }}>
                          {PREVIEW_SAMPLES.button}
                        </button>
                      </Box>
                    </BlockStack>
                  </Box>
                )}
              </Tabs>
            </Card>
          </Layout.Section>

          {/* Sidebar - Quick Summary */}
          <Layout.Section variant="oneThird">
            <BlockStack gap="400">
              <Card>
                <BlockStack gap="300">
                  <Text as="h3" variant="headingMd">Font Summary</Text>
                  <Divider />
                  {[
                    { label: "Headings", value: headingFont || "Theme default" },
                    { label: "Body Text", value: bodyFont || "Theme default" },
                    { label: "Buttons", value: buttonFont || "Theme default" },
                    { label: "Navigation", value: navFont || "Theme default" },
                  ].map(({ label, value }) => (
                    <InlineStack key={label} align="space-between">
                      <Text as="span" variant="bodySm" tone="subdued">{label}</Text>
                      <Text as="span" variant="bodySm" fontWeight="semibold">{value}</Text>
                    </InlineStack>
                  ))}
                </BlockStack>
              </Card>

              <Card>
                <BlockStack gap="300">
                  <Text as="h3" variant="headingMd">Quick Font Swap</Text>
                  <Text as="p" variant="bodySm" tone="subdued">
                    Quickly apply a single font to all elements
                  </Text>
                  {fontFamilies.slice(0, 5).map(family => (
                    <Button
                      key={family}
                      size="slim"
                      onClick={() => {
                        setHeadingFont(family);
                        setBodyFont(family);
                        setButtonFont(family);
                        setNavFont(family);
                      }}
                    >
                      Apply "{family}" everywhere
                    </Button>
                  ))}
                  {fontFamilies.length === 0 && (
                    <Text as="p" variant="bodySm" tone="subdued">
                      Upload fonts to see options here
                    </Text>
                  )}
                </BlockStack>
              </Card>

              <Card>
                <BlockStack gap="300">
                  <Text as="h3" variant="headingMd">Generated CSS</Text>
                  <Text as="p" variant="bodySm" tone="subdued">
                    The CSS below will be injected into your theme as <code>assets/font-vault.css</code>
                  </Text>
                  {fetcher.data?.css && (
                    <Box
                      background="bg-surface-secondary"
                      padding="300"
                      borderRadius="100"
                    >
                      <Text as="p" variant="bodyXs" fontWeight="medium">
                        <pre style={{ fontSize: "10px", overflow: "auto", maxHeight: "200px" }}>
                          {fetcher.data.css.slice(0, 500)}...
                        </pre>
                      </Text>
                    </Box>
                  )}
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}
