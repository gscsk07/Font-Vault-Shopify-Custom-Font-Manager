import { useState, useCallback, useRef } from "react";
import { useLoaderData, useFetcher, useNavigate, useSearchParams } from "@remix-run/react";
import type { LoaderFunctionArgs, ActionFunctionArgs } from "@remix-run/node";
import { json, unstable_parseMultipartFormData } from "@remix-run/node";
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  BlockStack,
  InlineStack,
  Badge,
  Banner,
  Modal,
  TextField,
  Select,
  DataTable,
  Thumbnail,
  Icon,
  Divider,
  Box,
  EmptyState,
  Tabs,
  Tooltip,
  ActionList,
  Popover,
} from "@shopify/polaris";
import { DeleteIcon, ViewIcon, UploadIcon } from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";
import {
  getFonts,
  createFont,
  deleteFont,
  validateFontFile,
  getFontFamiliesFromFonts,
  uploadFontToShopify,
  getThemes,
} from "../lib/font.server";
import type { FontFile } from "@prisma/client";

export async function loader({ request }: LoaderFunctionArgs) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const [fonts, themes] = await Promise.all([getFonts(shop), getThemes(admin)]);
  const activeTheme = themes.find((t: any) => t.role === "MAIN");
  return json({ fonts, activeThemeId: activeTheme?.id?.replace("gid://shopify/OnlineStoreTheme/", "") });
}

export async function action({ request }: ActionFunctionArgs) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const formData = await request.formData();
  const intent = formData.get("intent") as string;

  if (intent === "delete") {
    const id = formData.get("id") as string;
    await deleteFont(id, shop);
    return json({ success: true, action: "deleted" });
  }

  if (intent === "upload") {
    const file = formData.get("file") as File;
    const family = formData.get("family") as string;
    const weight = formData.get("weight") as string;
    const style = formData.get("style") as string;
    const category = formData.get("category") as string;
    const themeId = formData.get("themeId") as string;

    if (!file || !family) {
      return json({ success: false, error: "File and font family are required" });
    }

    const validation = validateFontFile(file.name);
    if (!validation.valid) {
      return json({ success: false, error: validation.error });
    }

    try {
      // Read file as base64
      const buffer = await file.arrayBuffer();
      const base64 = Buffer.from(buffer).toString("base64");
      const fileName = file.name.replace(/\s+/g, "-").toLowerCase();

      // Upload to theme assets
      const assetPath = await uploadFontToShopify(admin, themeId, fileName, base64);

      // Get the CDN URL (Shopify theme asset URL)
      const fileUrl = `{{ '${fileName}' | asset_url }}`;

      // Save to database
      const font = await createFont({
        shop,
        name: file.name,
        family,
        weight: weight || "400",
        style: style || "normal",
        format: validation.format,
        fileName,
        fileUrl,
        fileSize: file.size,
        category: category || "sans-serif",
      });

      return json({ success: true, action: "uploaded", font });
    } catch (error) {
      return json({ success: false, error: String(error) });
    }
  }

  return json({ success: false, error: "Unknown action" });
}

const FONT_WEIGHTS = [
  { label: "100 - Thin", value: "100" },
  { label: "200 - Extra Light", value: "200" },
  { label: "300 - Light", value: "300" },
  { label: "400 - Regular", value: "400" },
  { label: "500 - Medium", value: "500" },
  { label: "600 - Semi Bold", value: "600" },
  { label: "700 - Bold", value: "700" },
  { label: "800 - Extra Bold", value: "800" },
  { label: "900 - Black", value: "900" },
];

const FONT_CATEGORIES = [
  { label: "Sans Serif", value: "sans-serif" },
  { label: "Serif", value: "serif" },
  { label: "Monospace", value: "monospace" },
  { label: "Display", value: "display" },
  { label: "Handwriting", value: "handwriting" },
];

export default function FontsPage() {
  const { fonts, activeThemeId } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<any>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [previewFont, setPreviewFont] = useState<FontFile | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [selectedTab, setSelectedTab] = useState(0);

  // Upload form state
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fontFamily, setFontFamily] = useState("");
  const [fontWeight, setFontWeight] = useState("400");
  const [fontStyle, setFontStyle] = useState("normal");
  const [fontCategory, setFontCategory] = useState("sans-serif");
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isSubmitting = fetcher.state !== "idle";
  const previewText = "The quick brown fox jumps over the lazy dog — 0123456789";

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    // Auto-detect family name from file name
    const nameParts = file.name.replace(/\.(woff2?|ttf|otf)$/i, "").split(/[-_\s]+/);
    const familyName = nameParts
      .filter(p => !["regular", "bold", "light", "thin", "medium", "italic", "black", "100","200","300","400","500","600","700","800","900"].includes(p.toLowerCase()))
      .join(" ");
    if (!fontFamily) setFontFamily(familyName);

    // Auto-detect weight
    const name = file.name.toLowerCase();
    if (name.includes("thin") || name.includes("100")) setFontWeight("100");
    else if (name.includes("extralight") || name.includes("200")) setFontWeight("200");
    else if (name.includes("light") || name.includes("300")) setFontWeight("300");
    else if (name.includes("medium") || name.includes("500")) setFontWeight("500");
    else if (name.includes("semibold") || name.includes("600")) setFontWeight("600");
    else if (name.includes("bold") || name.includes("700")) setFontWeight("700");
    else if (name.includes("extrabold") || name.includes("800")) setFontWeight("800");
    else if (name.includes("black") || name.includes("900")) setFontWeight("900");
    else setFontWeight("400");

    if (name.includes("italic")) setFontStyle("italic");
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }, []);

  const handleUploadSubmit = () => {
    if (!selectedFile || !fontFamily || !activeThemeId) return;

    const formData = new FormData();
    formData.append("intent", "upload");
    formData.append("file", selectedFile);
    formData.append("family", fontFamily);
    formData.append("weight", fontWeight);
    formData.append("style", fontStyle);
    formData.append("category", fontCategory);
    formData.append("themeId", activeThemeId);

    fetcher.submit(formData, { method: "post", encType: "multipart/form-data" });
    setUploadModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setSelectedFile(null);
    setFontFamily("");
    setFontWeight("400");
    setFontStyle("normal");
    setFontCategory("sans-serif");
  };

  const handleDelete = (id: string) => {
    const formData = new FormData();
    formData.append("intent", "delete");
    formData.append("id", id);
    fetcher.submit(formData, { method: "post" });
    setDeleteConfirmId(null);
  };

  // Group fonts by family
  const fontFamilies = getFontFamiliesFromFonts(fonts as any);
  const fontsByFamily = fontFamilies.map(family => ({
    family,
    fonts: fonts.filter((f: any) => f.family === family),
  }));

  const tabs = [
    { id: "library", content: `Library (${fonts.length})` },
    { id: "families", content: `Families (${fontFamilies.length})` },
    { id: "preview", content: "Preview" },
  ];

  return (
    <Page
      title="Font Library"
      subtitle="Upload and manage custom fonts for your store"
      primaryAction={{
        content: "Upload Font",
        onAction: () => setUploadModalOpen(true),
      }}
      backAction={{ content: "Dashboard", url: "/app" }}
    >
      <BlockStack gap="500">
        {fetcher.data?.error && (
          <Banner tone="critical" title="Upload Error">
            <p>{fetcher.data.error}</p>
          </Banner>
        )}
        {fetcher.data?.action === "uploaded" && (
          <Banner tone="success" title="Font uploaded successfully!">
            <p>"{fetcher.data.font?.name}" has been added to your library.</p>
          </Banner>
        )}

        <Tabs tabs={tabs} selected={selectedTab} onSelect={setSelectedTab}>
          {/* Library Tab */}
          {selectedTab === 0 && (
            <Card>
              {fonts.length === 0 ? (
                <EmptyState
                  heading="No fonts uploaded yet"
                  action={{ content: "Upload Your First Font", onAction: () => setUploadModalOpen(true) }}
                  image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                >
                  <p>Upload .woff2, .woff, .ttf or .otf files to get started.</p>
                </EmptyState>
              ) : (
                <DataTable
                  columnContentTypes={["text", "text", "text", "text", "text", "text"]}
                  headings={["Font Name", "Family", "Weight", "Style", "Format", "Actions"]}
                  rows={fonts.map((font: any) => [
                    <Text as="span" variant="bodyMd" fontWeight="semibold">{font.name}</Text>,
                    font.family,
                    <Badge>{font.weight}</Badge>,
                    font.style,
                    <Badge tone="info">{font.format.toUpperCase()}</Badge>,
                    <InlineStack gap="200">
                      <Button
                        size="slim"
                        icon={ViewIcon}
                        onClick={() => setPreviewFont(font)}
                      >
                        Preview
                      </Button>
                      <Button
                        size="slim"
                        tone="critical"
                        icon={DeleteIcon}
                        onClick={() => setDeleteConfirmId(font.id)}
                      >
                        Delete
                      </Button>
                    </InlineStack>,
                  ])}
                />
              )}
            </Card>
          )}

          {/* Families Tab */}
          {selectedTab === 1 && (
            <BlockStack gap="400">
              {fontsByFamily.length === 0 ? (
                <Card>
                  <EmptyState
                    heading="No font families yet"
                    action={{ content: "Upload Fonts", onAction: () => setUploadModalOpen(true) }}
                    image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                  >
                    <p>Upload fonts to see them organized by family.</p>
                  </EmptyState>
                </Card>
              ) : (
                fontsByFamily.map(({ family, fonts: familyFonts }) => (
                  <Card key={family}>
                    <BlockStack gap="300">
                      <InlineStack align="space-between">
                        <Text as="h3" variant="headingMd">{family}</Text>
                        <Badge>{familyFonts.length} variant{familyFonts.length !== 1 ? "s" : ""}</Badge>
                      </InlineStack>
                      <Divider />
                      <BlockStack gap="200">
                        {familyFonts.map((font: any) => (
                          <InlineStack key={font.id} align="space-between" blockAlign="center">
                            <InlineStack gap="300" blockAlign="center">
                              <Badge tone="info">{font.format.toUpperCase()}</Badge>
                              <Text as="span" variant="bodySm">Weight {font.weight}</Text>
                              <Text as="span" variant="bodySm" tone="subdued">{font.style}</Text>
                              <Text as="span" variant="bodySm" tone="subdued">
                                {Math.round(font.fileSize / 1024)}KB
                              </Text>
                            </InlineStack>
                            <Button size="slim" tone="critical" onClick={() => setDeleteConfirmId(font.id)}>
                              Remove
                            </Button>
                          </InlineStack>
                        ))}
                      </BlockStack>
                    </BlockStack>
                  </Card>
                ))
              )}
            </BlockStack>
          )}

          {/* Preview Tab */}
          {selectedTab === 2 && (
            <BlockStack gap="400">
              {fontFamilies.length === 0 ? (
                <Card>
                  <EmptyState
                    heading="No fonts to preview"
                    action={{ content: "Upload Fonts", onAction: () => setUploadModalOpen(true) }}
                    image="https://cdn.shopify.com/s/files/1/0262/4071/2726/files/emptystate-files.png"
                  >
                    <p>Upload fonts first to preview them here.</p>
                  </EmptyState>
                </Card>
              ) : (
                fontFamilies.map(family => (
                  <Card key={family}>
                    <BlockStack gap="400">
                      <InlineStack align="space-between">
                        <Text as="h3" variant="headingMd">{family}</Text>
                        <Button size="slim" onClick={() => navigate(`/app/typography?headingFont=${encodeURIComponent(family)}`)}>
                          Use for Headings
                        </Button>
                      </InlineStack>
                      <Divider />
                      {/* Font Preview using CSS vars */}
                      <Box
                        padding="400"
                        background="bg-surface-secondary"
                        borderRadius="200"
                      >
                        <BlockStack gap="300">
                          <div style={{ fontFamily: `"${family}", sans-serif`, fontSize: "32px", fontWeight: "700", lineHeight: "1.2" }}>
                            {family} — Heading Display
                          </div>
                          <div style={{ fontFamily: `"${family}", sans-serif`, fontSize: "18px", fontWeight: "400", lineHeight: "1.6", color: "#555" }}>
                            {previewText}
                          </div>
                          <div style={{ fontFamily: `"${family}", sans-serif`, fontSize: "14px", fontWeight: "400", lineHeight: "1.5", color: "#777" }}>
                            ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz
                          </div>
                          <InlineStack gap="300" wrap>
                            {["100","200","300","400","500","600","700","800","900"]
                              .filter(w => fonts.some((f: any) => f.family === family && f.weight === w))
                              .map(weight => (
                                <Box key={weight} padding="200" background="bg-surface" borderRadius="100" borderWidth="025" borderColor="border">
                                  <span style={{ fontFamily: `"${family}", sans-serif`, fontWeight: weight, fontSize: "14px" }}>
                                    {weight} — Aa
                                  </span>
                                </Box>
                              ))
                            }
                          </InlineStack>
                        </BlockStack>
                      </Box>
                    </BlockStack>
                  </Card>
                ))
              )}
            </BlockStack>
          )}
        </Tabs>
      </BlockStack>

      {/* Upload Modal */}
      <Modal
        open={uploadModalOpen}
        onClose={() => { setUploadModalOpen(false); resetForm(); }}
        title="Upload Font File"
        primaryAction={{
          content: "Upload Font",
          onAction: handleUploadSubmit,
          disabled: !selectedFile || !fontFamily || isSubmitting,
          loading: isSubmitting,
        }}
        secondaryActions={[{ content: "Cancel", onAction: () => { setUploadModalOpen(false); resetForm(); } }]}
      >
        <Modal.Section>
          <BlockStack gap="400">
            {/* Drop Zone */}
            <div
              onDrop={handleDrop}
              onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onClick={() => fileInputRef.current?.click()}
              style={{
                border: `2px dashed ${dragOver ? "#008060" : "#c9cccf"}`,
                borderRadius: "8px",
                padding: "32px",
                textAlign: "center",
                cursor: "pointer",
                background: dragOver ? "#f1f8f5" : "#fafafa",
                transition: "all 0.2s",
              }}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".woff2,.woff,.ttf,.otf"
                style={{ display: "none" }}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFileSelect(f);
                }}
              />
              <BlockStack gap="200" align="center">
                <Text as="p" variant="bodyLg" fontWeight="semibold">
                  {selectedFile ? `✅ ${selectedFile.name}` : "Drop font file here or click to browse"}
                </Text>
                <Text as="p" variant="bodySm" tone="subdued">
                  Supported formats: .woff2, .woff, .ttf, .otf
                </Text>
                {selectedFile && (
                  <Text as="p" variant="bodySm" tone="subdued">
                    Size: {Math.round(selectedFile.size / 1024)}KB
                  </Text>
                )}
              </BlockStack>
            </div>

            <TextField
              label="Font Family Name"
              value={fontFamily}
              onChange={setFontFamily}
              placeholder="e.g. My Brand Font"
              helpText="Group fonts by the same family name (e.g. 'Playfair Display')"
              autoComplete="off"
            />

            <InlineStack gap="400">
              <div style={{ flex: 1 }}>
                <Select
                  label="Font Weight"
                  options={FONT_WEIGHTS}
                  value={fontWeight}
                  onChange={setFontWeight}
                />
              </div>
              <div style={{ flex: 1 }}>
                <Select
                  label="Font Style"
                  options={[
                    { label: "Normal", value: "normal" },
                    { label: "Italic", value: "italic" },
                  ]}
                  value={fontStyle}
                  onChange={setFontStyle}
                />
              </div>
            </InlineStack>

            <Select
              label="Font Category"
              options={FONT_CATEGORIES}
              value={fontCategory}
              onChange={setFontCategory}
              helpText="Used for fallback font-family stack"
            />
          </BlockStack>
        </Modal.Section>
      </Modal>

      {/* Delete Confirm Modal */}
      <Modal
        open={!!deleteConfirmId}
        onClose={() => setDeleteConfirmId(null)}
        title="Delete Font"
        primaryAction={{
          content: "Delete",
          onAction: () => deleteConfirmId && handleDelete(deleteConfirmId),
          tone: "critical",
        }}
        secondaryActions={[{ content: "Cancel", onAction: () => setDeleteConfirmId(null) }]}
      >
        <Modal.Section>
          <Text as="p">Are you sure you want to delete this font? This cannot be undone. If it's in use, your typography settings may be affected.</Text>
        </Modal.Section>
      </Modal>
    </Page>
  );
}
