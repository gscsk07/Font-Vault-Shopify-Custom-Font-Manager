import { useLoaderData, useNavigate } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import {
  Page,
  Layout,
  Card,
  Text,
  Button,
  BlockStack,
  InlineStack,
  Badge,
  Banner,
  Divider,
  Box,
  Grid,
} from "@shopify/polaris";
import {
  FontsIcon,
  TextIcon,
  ThemeIcon,
  WandIcon,
} from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";
import {
  getFonts,
  getTypographySettings,
  getThemes,
} from "../lib/font.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;

  const [fonts, typographySettings, themes] = await Promise.all([
    getFonts(shop),
    getTypographySettings(shop),
    getThemes(admin),
  ]);

  const activeTheme = themes.find((t: any) => t.role === "MAIN");

  return json({
    shop,
    fontCount: fonts.length,
    fontFamilyCount: new Set(fonts.map((f: any) => f.family)).size,
    typographyActive: typographySettings?.isActive ?? false,
    activeThemeName: activeTheme?.name ?? "No active theme",
    themes,
  });
}

export default function Index() {
  const { fontCount, fontFamilyCount, typographyActive, activeThemeName, themes } =
    useLoaderData<typeof loader>();
  const navigate = useNavigate();

  return (
    <Page
      title="Font Vault Shopify Custom Font Manager"
      subtitle="Custom Font Manager for Shopify"
    >
      <BlockStack gap="500">
        {typographyActive && (
          <Banner
            title="Typography is live on your store"
            tone="success"
            action={{ content: "View Settings", onAction: () => navigate("/app/typography") }}
          >
            <p>Your custom fonts and typography settings are currently applied to <strong>{activeThemeName}</strong>.</p>
          </Banner>
        )}

        {!typographyActive && fontCount > 0 && (
          <Banner
            title="Typography not yet applied"
            tone="warning"
            action={{ content: "Apply to Theme", onAction: () => navigate("/app/typography") }}
          >
            <p>You have {fontCount} font{fontCount !== 1 ? "s" : ""} uploaded but typography overrides are not active.</p>
          </Banner>
        )}

        {/* Stats Cards */}
        <Grid>
          <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 3, xl: 3 }}>
            <Card>
              <BlockStack gap="200">
                <Text as="h3" variant="headingMd">Font Files</Text>
                <Text as="p" variant="heading2xl" fontWeight="bold">{fontCount}</Text>
                <Text as="p" variant="bodyMd" tone="subdued">uploaded fonts</Text>
              </BlockStack>
            </Card>
          </Grid.Cell>

          <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 3, xl: 3 }}>
            <Card>
              <BlockStack gap="200">
                <Text as="h3" variant="headingMd">Font Families</Text>
                <Text as="p" variant="heading2xl" fontWeight="bold">{fontFamilyCount}</Text>
                <Text as="p" variant="bodyMd" tone="subdued">unique families</Text>
              </BlockStack>
            </Card>
          </Grid.Cell>

          <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 3, xl: 3 }}>
            <Card>
              <BlockStack gap="200">
                <Text as="h3" variant="headingMd">Active Theme</Text>
                <Text as="p" variant="headingLg" fontWeight="bold" breakWord>{activeThemeName}</Text>
                <Text as="p" variant="bodyMd" tone="subdued">current theme</Text>
              </BlockStack>
            </Card>
          </Grid.Cell>

          <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 3, xl: 3 }}>
            <Card>
              <BlockStack gap="200">
                <Text as="h3" variant="headingMd">Typography</Text>
                <InlineStack gap="200" align="start" blockAlign="center">
                  <Badge tone={typographyActive ? "success" : "attention"}>
                    {typographyActive ? "Active" : "Inactive"}
                  </Badge>
                </InlineStack>
                <Text as="p" variant="bodyMd" tone="subdued">override status</Text>
              </BlockStack>
            </Card>
          </Grid.Cell>
        </Grid>

        <Divider />

        {/* Quick Actions */}
        <Layout>
          <Layout.Section>
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">Quick Actions</Text>
                <Grid>
                  <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                    <Card background="bg-surface-secondary">
                      <BlockStack gap="300">
                        <Text as="h3" variant="headingMd">📁 Upload Fonts</Text>
                        <Text as="p" variant="bodyMd" tone="subdued">
                          Upload .woff2, .woff, .ttf, or .otf font files to your store's library.
                          Supports multiple weights and styles per family.
                        </Text>
                        <Button onClick={() => navigate("/app/fonts")}>
                          Go to Font Library
                        </Button>
                      </BlockStack>
                    </Card>
                  </Grid.Cell>

                  <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                    <Card background="bg-surface-secondary">
                      <BlockStack gap="300">
                        <Text as="h3" variant="headingMd">🎨 Typography Controls</Text>
                        <Text as="p" variant="bodyMd" tone="subdued">
                          Control heading, body, button, and navigation fonts. Adjust sizes,
                          weights, line heights, and letter spacing.
                        </Text>
                        <Button onClick={() => navigate("/app/typography")}>
                          Open Typography
                        </Button>
                      </BlockStack>
                    </Card>
                  </Grid.Cell>

                  <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                    <Card background="bg-surface-secondary">
                      <BlockStack gap="300">
                        <Text as="h3" variant="headingMd">👁️ Font Preview</Text>
                        <Text as="p" variant="bodyMd" tone="subdued">
                          Preview how your fonts look with sample text at different sizes
                          and styles before applying them.
                        </Text>
                        <Button onClick={() => navigate("/app/fonts?preview=true")}>
                          Preview Fonts
                        </Button>
                      </BlockStack>
                    </Card>
                  </Grid.Cell>

                  <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 6, xl: 6 }}>
                    <Card background="bg-surface-secondary">
                      <BlockStack gap="300">
                        <Text as="h3" variant="headingMd">⚙️ App Settings</Text>
                        <Text as="p" variant="bodyMd" tone="subdued">
                          Configure which theme receives your custom fonts, manage CSS injection,
                          and set custom CSS overrides.
                        </Text>
                        <Button onClick={() => navigate("/app/settings")}>
                          Open Settings
                        </Button>
                      </BlockStack>
                    </Card>
                  </Grid.Cell>
                </Grid>
              </BlockStack>
            </Card>
          </Layout.Section>

          <Layout.Section variant="oneThird">
            <Card>
              <BlockStack gap="400">
                <Text as="h2" variant="headingLg">📖 How It Works</Text>
                <BlockStack gap="300">
                  <Box borderColor="border" borderWidth="025" borderRadius="200" padding="300">
                    <BlockStack gap="100">
                      <Text as="p" variant="bodySm" fontWeight="bold">① Upload</Text>
                      <Text as="p" variant="bodySm" tone="subdued">
                        Upload your font files. They're stored as theme assets.
                      </Text>
                    </BlockStack>
                  </Box>
                  <Box borderColor="border" borderWidth="025" borderRadius="200" padding="300">
                    <BlockStack gap="100">
                      <Text as="p" variant="bodySm" fontWeight="bold">② Configure</Text>
                      <Text as="p" variant="bodySm" tone="subdued">
                        Choose fonts for headings, body, buttons and nav. Adjust all typography settings.
                      </Text>
                    </BlockStack>
                  </Box>
                  <Box borderColor="border" borderWidth="025" borderRadius="200" padding="300">
                    <BlockStack gap="100">
                      <Text as="p" variant="bodySm" fontWeight="bold">③ Apply</Text>
                      <Text as="p" variant="bodySm" tone="subdued">
                        CSS is injected into your theme, overriding default typography globally.
                      </Text>
                    </BlockStack>
                  </Box>
                  <Box borderColor="border" borderWidth="025" borderRadius="200" padding="300">
                    <BlockStack gap="100">
                      <Text as="p" variant="bodySm" fontWeight="bold">④ Preview</Text>
                      <Text as="p" variant="bodySm" tone="subdued">
                        Preview your live store to see the fonts applied instantly.
                      </Text>
                    </BlockStack>
                  </Box>
                </BlockStack>
              </BlockStack>
            </Card>
          </Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}
