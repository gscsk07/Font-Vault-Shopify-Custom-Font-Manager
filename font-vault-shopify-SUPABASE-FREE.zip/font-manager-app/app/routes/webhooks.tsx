import { authenticate } from "../shopify.server";
import type { ActionFunctionArgs } from "@remix-run/node";

export const action = async ({ request }: ActionFunctionArgs) => {
  const { topic, shop, session, admin, payload } = await authenticate.webhook(request);

  if (!admin && topic !== "CUSTOMERS_DATA_REQUEST") {
    throw new Response();
  }

  switch (topic) {
    case "APP_UNINSTALLED":
      // Clean up shop data when app is uninstalled
      if (session) {
        const { prisma } = await import("../shopify.server");
        await prisma.fontFile.deleteMany({ where: { shop } });
        await prisma.typographySettings.deleteMany({ where: { shop } });
        await prisma.session.deleteMany({ where: { shop } });
      }
      break;

    case "CUSTOMERS_DATA_REQUEST":
      // GDPR: respond with data request
      break;

    case "CUSTOMERS_REDACT":
      // GDPR: delete customer data
      break;

    case "SHOP_REDACT":
      // GDPR: delete all shop data
      const { prisma } = await import("../shopify.server");
      await prisma.fontFile.deleteMany({ where: { shop } });
      await prisma.typographySettings.deleteMany({ where: { shop } });
      await prisma.session.deleteMany({ where: { shop } });
      break;

    default:
      throw new Response("Unhandled webhook topic", { status: 404 });
  }

  throw new Response();
};
