-- CreateTable
CREATE TABLE "Session" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "isOnline" BOOLEAN NOT NULL DEFAULT false,
    "scope" TEXT,
    "expires" TIMESTAMP(3),
    "accessToken" TEXT NOT NULL,
    "userId" BIGINT,
    "firstName" TEXT,
    "lastName" TEXT,
    "email" TEXT,
    "accountOwner" BOOLEAN NOT NULL DEFAULT false,
    "locale" TEXT,
    "collaborator" BOOLEAN DEFAULT false,
    "emailVerified" BOOLEAN DEFAULT false,

    CONSTRAINT "Session_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FontFile" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "family" TEXT NOT NULL,
    "weight" TEXT NOT NULL DEFAULT '400',
    "style" TEXT NOT NULL DEFAULT 'normal',
    "format" TEXT NOT NULL,
    "fileName" TEXT NOT NULL,
    "fileUrl" TEXT NOT NULL,
    "fileSize" INTEGER NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'sans-serif',
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "FontFile_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TypographySettings" (
    "id" TEXT NOT NULL,
    "shop" TEXT NOT NULL,
    "headingFontFamily" TEXT,
    "headingFontSize" TEXT NOT NULL DEFAULT '2.5rem',
    "headingH2Size" TEXT NOT NULL DEFAULT '2rem',
    "headingH3Size" TEXT NOT NULL DEFAULT '1.75rem',
    "headingH4Size" TEXT NOT NULL DEFAULT '1.5rem',
    "headingH5Size" TEXT NOT NULL DEFAULT '1.25rem',
    "headingH6Size" TEXT NOT NULL DEFAULT '1rem',
    "headingFontWeight" TEXT NOT NULL DEFAULT '700',
    "headingLineHeight" TEXT NOT NULL DEFAULT '1.2',
    "headingLetterSpacing" TEXT NOT NULL DEFAULT '0em',
    "headingColor" TEXT NOT NULL DEFAULT '#000000',
    "headingTextTransform" TEXT NOT NULL DEFAULT 'none',
    "bodyFontFamily" TEXT,
    "bodyFontSize" TEXT NOT NULL DEFAULT '1rem',
    "bodyFontWeight" TEXT NOT NULL DEFAULT '400',
    "bodyLineHeight" TEXT NOT NULL DEFAULT '1.6',
    "bodyLetterSpacing" TEXT NOT NULL DEFAULT '0em',
    "bodyColor" TEXT NOT NULL DEFAULT '#333333',
    "bodyTextTransform" TEXT NOT NULL DEFAULT 'none',
    "buttonFontFamily" TEXT,
    "buttonFontSize" TEXT NOT NULL DEFAULT '1rem',
    "buttonFontWeight" TEXT NOT NULL DEFAULT '600',
    "buttonLineHeight" TEXT NOT NULL DEFAULT '1.4',
    "buttonLetterSpacing" TEXT NOT NULL DEFAULT '0.05em',
    "buttonColor" TEXT NOT NULL DEFAULT '#ffffff',
    "buttonTextTransform" TEXT NOT NULL DEFAULT 'uppercase',
    "navFontFamily" TEXT,
    "navFontSize" TEXT NOT NULL DEFAULT '0.875rem',
    "navFontWeight" TEXT NOT NULL DEFAULT '500',
    "navLetterSpacing" TEXT NOT NULL DEFAULT '0.05em',
    "navTextTransform" TEXT NOT NULL DEFAULT 'none',
    "metaFontFamily" TEXT,
    "metaFontSize" TEXT NOT NULL DEFAULT '0.875rem',
    "metaFontWeight" TEXT NOT NULL DEFAULT '400',
    "metaLineHeight" TEXT NOT NULL DEFAULT '1.5',
    "metaLetterSpacing" TEXT NOT NULL DEFAULT '0em',
    "baseScale" TEXT NOT NULL DEFAULT '1',
    "isActive" BOOLEAN NOT NULL DEFAULT false,
    "customCSS" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TypographySettings_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "FontFile_shop_idx" ON "FontFile"("shop");

-- CreateIndex
CREATE INDEX "FontFile_shop_family_idx" ON "FontFile"("shop", "family");

-- CreateIndex
CREATE UNIQUE INDEX "TypographySettings_shop_key" ON "TypographySettings"("shop");

-- CreateIndex
CREATE INDEX "TypographySettings_shop_idx" ON "TypographySettings"("shop");
